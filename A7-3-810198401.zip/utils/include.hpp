#ifndef __INCLUDE__
#define __INCLUDE__

#define BUFSIZE 4145152
enum Method { GET, POST };

#endif
